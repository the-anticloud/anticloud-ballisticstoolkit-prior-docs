# Command Line Interface — BALLISTICSTOOLKIT

**Upstream:** https://github.com/chasep255/BallisticsToolkit

## Anticloud CLI

```bash
# Install
pip install anticloud-ballisticstoolkit

# Run offline with PAX inference
anticloud-ballisticstoolkit --offline --pax-local

# Run with AIOSS logging
anticloud-ballisticstoolkit --aioss-log ./ledger.jsonl

# Single binary (after build)
./ballisticstoolkit --config config.yaml
```

## Options

| Flag | Description |
| --- | --- |
| `--offline` | Disable all network calls |
| `--pax-local` | Use local PAX inference at 127.0.0.1:11434 |
| `--aioss-log PATH` | Write AIOSS audit chain to PATH |
| `--encrypt` | Enable AES-256 at rest for output files |
| `--gpu` | Force GPU inference |
| `--cpu` | Force CPU inference |
| `--config PATH` | Load configuration from YAML file |
