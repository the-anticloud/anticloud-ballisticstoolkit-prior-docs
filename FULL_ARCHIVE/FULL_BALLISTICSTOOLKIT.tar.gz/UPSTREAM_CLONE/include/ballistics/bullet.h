#pragma once

#include "math/conversions.h"
#include "math/vector.h"
#include "physics/constants.h"
#include <cmath>

namespace btk::ballistics
{

  /**
   * @brief Drag function types for ballistics calculations
   */
  enum DragFunction : uint8_t
  {
    G1 = 0,
    G7 = 1
  };

  /**
   * @brief Represents a bullet with physical properties and ballistic coefficient
   *
   * A bullet can have either a G1 or G7 BC, but not both. The drag_function
   * attribute indicates which one is being used.
   *
   * The bullet can also represent a flying bullet with position, velocity, and spin state.
   */
  class Bullet
  {
    public:
    /**
     * @brief Initialize a bullet (static properties only)
     *
     * @param weight Bullet weight in kg
     * @param diameter Bullet diameter in m
     * @param length Bullet length in m
     * @param bc Ballistic coefficient (G1 or G7 depending on drag_function)
     * @param drag_function Drag function type (default: G7)
     */
    constexpr Bullet(float weight, float diameter, float length, float bc, DragFunction drag_function = DragFunction::G7)
      : weight_(weight), diameter_(diameter), length_(length), bc_(bc), drag_function_(drag_function), position_(0.0f, 0.0f, 0.0f), velocity_(0.0f, 0.0f, 0.0f), spin_rate_(0.0f),
        has_flight_state_(false)
    {
    }

    /**
     * @brief Initialize a flying bullet with 4DOF state
     *
     * @param bullet The bullet object with physical properties and BC
     * @param position 3D position vector in m
     * @param velocity 3D velocity vector in m/s
     * @param spin_rate Spin rate around the velocity vector in rad/s (for Magnus effects)
     */
    constexpr Bullet(const Bullet& bullet, const btk::math::Vector3D& position, const btk::math::Vector3D& velocity, float spin_rate)
      : weight_(bullet.weight_), diameter_(bullet.diameter_), length_(bullet.length_), bc_(bullet.bc_), drag_function_(bullet.drag_function_), position_(position), velocity_(velocity),
        spin_rate_(spin_rate), has_flight_state_(true)
    {
    }

    /**
     * @brief Initialize a flying bullet with 4DOF state (legacy constructor)
     *
     * @param bullet The bullet object with physical properties and BC
     * @param position_x Position along X axis in m (crossrange)
     * @param position_y Position along Y axis in m (vertical/up)
     * @param position_z Position along Z axis in m (-downrange)
     * @param velocity_x Velocity component along X axis in m/s
     * @param velocity_y Velocity component along Y axis in m/s
     * @param velocity_z Velocity component along Z axis in m/s
     * @param spin_rate Spin rate around the velocity vector in rad/s (for Magnus effects)
     */
    constexpr Bullet(const Bullet& bullet, float position_x, float position_y, float position_z, float velocity_x, float velocity_y, float velocity_z, float spin_rate)
      : weight_(bullet.weight_), diameter_(bullet.diameter_), length_(bullet.length_), bc_(bullet.bc_), drag_function_(bullet.drag_function_), position_(position_x, position_y, position_z),
        velocity_(velocity_x, velocity_y, velocity_z), spin_rate_(spin_rate), has_flight_state_(true)
    {
    }

    // Getters (all return SI base units)
    constexpr float getWeight() const { return weight_; }     // kg
    constexpr float getDiameter() const { return diameter_; } // m
    constexpr float getLength() const { return length_; }     // m
    constexpr float getBc() const { return bc_; }
    constexpr DragFunction getDragFunction() const { return drag_function_; }

    /**
     * @brief Calculate sectional density (weight/diameter²)
     *
     * @return Sectional density in kg/m² (SI units)
     */
    constexpr float getSectionalDensity() const { return weight_ / (diameter_ * diameter_); }

    // Flight state methods (only valid if has_flight_state_ is true)
    constexpr bool hasFlightState() const { return has_flight_state_; }

    constexpr const btk::math::Vector3D& getPosition() const { return position_; } // m
    constexpr const btk::math::Vector3D& getVelocity() const { return velocity_; } // m/s

    // Individual component getters (for compatibility)
    constexpr float getPositionX() const { return position_.x; } // m
    constexpr float getPositionY() const { return position_.y; } // m
    constexpr float getPositionZ() const { return position_.z; } // m
    constexpr float getVelocityX() const { return velocity_.x; } // m/s
    constexpr float getVelocityY() const { return velocity_.y; } // m/s
    constexpr float getVelocityZ() const { return velocity_.z; } // m/s
    constexpr float getSpinRate() const { return spin_rate_; }   // rad/s

    // Compute spin rate from signed twist pitch (meters/turn). RH>0, LH<0
    static constexpr float computeSpinRateFromTwist(float speed_mps, float twist_pitch_m_signed)
    {
      if(twist_pitch_m_signed == 0.0f)
        return 0.0f;
      float omega_mag = 2.0f * M_PI_F * (speed_mps / std::abs(twist_pitch_m_signed));
      return (twist_pitch_m_signed > 0.0f ? omega_mag : -omega_mag);
    }

    /**
     * @brief Calculate total velocity magnitude from components
     */
    constexpr float getTotalVelocity() const
    {
      return velocity_.magnitude(); // m/s
    }

    /**
     * @brief Calculate elevation angle (pitch) from velocity vector
     *
     * @return Angle above horizontal plane in radians (positive = up)
     */
    constexpr float getElevationAngle() const
    {
      float horizontal = std::sqrt(velocity_.x * velocity_.x + velocity_.z * velocity_.z);
      return std::atan2(velocity_.y, horizontal); // rad
    }

    /**
     * @brief Calculate azimuth angle (bearing) from velocity vector
     *
     * Coordinate system: X=crossrange, Y=up, Z=-downrange
     * @return Horizontal angle from downrange (-Z) in radians (positive = rightward)
     */
    constexpr float getAzimuthAngle() const
    {
      return std::atan2(velocity_.x, -velocity_.z); // rad
    }

    /**
     * @brief Calculate Miller stability factor (SG) for a given twist rate
     *
     * Based on Miller twist rule: s = 30m / (t²d³l(1+l²))
     * where:
     *   m = bullet mass in grains
     *   t = twist rate in calibers per turn (T/d)
     *   d = bullet diameter in inches
     *   l = bullet length in calibers (L/d)
     *
     * @param twist_inches_per_turn Twist rate in inches per turn
     * @return Stability factor (dimensionless). Values > 1.5 are generally stable, > 2.0 is safer.
     */
    constexpr float computeMillerStabilityFactor(float twist_inches_per_turn) const
    {
      // Convert SI units to imperial for Miller formula
      float m_grains = btk::math::Conversions::kgToGrains(weight_);
      float d_inches = btk::math::Conversions::metersToInches(diameter_);
      float L_inches = btk::math::Conversions::metersToInches(length_);

      // Calculate length in calibers
      float l_calibers = L_inches / d_inches;

      // Calculate twist rate in calibers per turn
      float t_calibers_per_turn = twist_inches_per_turn / d_inches;

      // Miller formula: s = 30m / (t²d³l(1+l²))
      float numerator = 30.0f * m_grains;
      float t_squared = t_calibers_per_turn * t_calibers_per_turn;
      float d_cubed = d_inches * d_inches * d_inches;
      float l_term = l_calibers * (1.0f + l_calibers * l_calibers);
      float denominator = t_squared * d_cubed * l_term;

      if(denominator == 0.0f)
        return 0.0f;

      return numerator / denominator;
    }

    /**
     * @brief Miller stability factor corrected to actual muzzle conditions.
     *
     * Applies Miller's velocity and atmospheric corrections to the base factor,
     * matching the SG definition used by Litz's spin-drift and aerodynamic-jump
     * formulas (Applied Ballistics):
     *   SG = SG_base · (V/2800)^(1/3) · (T_°R / 519) · (29.92 / P_inHg)
     *
     * The base factor is calibrated at 2800 fps, 59 °F (519 °R), 29.92 inHg.
     *
     * @param twist_inches_per_turn Twist rate in inches per turn
     * @param velocity              Muzzle velocity in m/s
     * @param temperature           Air temperature in K
     * @param pressure              Barometric pressure in Pa
     * @return Corrected gyroscopic stability factor (dimensionless)
     */
    float computeMillerStabilityFactorCorrected(float twist_inches_per_turn, float velocity, float temperature, float pressure) const
    {
      float sg = computeMillerStabilityFactor(twist_inches_per_turn);

      float v_fps = btk::math::Conversions::mpsToFps(velocity);
      float p_inHg = btk::math::Conversions::pascalsToInHg(pressure);
      if(v_fps <= 0.0f || p_inHg <= 0.0f)
        return sg;

      float t_rankine = btk::math::Conversions::kelvinToRankine(temperature);

      sg *= std::cbrt(v_fps / 2800.0f);               // Miller velocity correction
      sg *= (t_rankine / 519.0f) * (29.92f / p_inHg); // Miller atmospheric (density) correction
      return sg;
    }

    /**
     * @brief Calculate ideal twist rate using Miller twist rule
     *
     * Inverted from SG = 30m / (t²d³l(1+l²)), solving for T = t*d:
     *   T = √(30m / (s * L * (1+l²)))
     * where:
     *   T = twist rate in inches per turn
     *   m = bullet mass in grains
     *   s = desired stability factor
     *   L = bullet length in inches
     *   l = L/d (length in calibers)
     *
     * @param stability_factor Desired stability factor (default 2.0, Miller's safe value)
     * @return Ideal twist rate in inches per turn
     */
    constexpr float computeIdealTwistRate(float stability_factor = 2.0f) const
    {
      float m_grains = btk::math::Conversions::kgToGrains(weight_);
      float d_inches = btk::math::Conversions::metersToInches(diameter_);
      float L_inches = btk::math::Conversions::metersToInches(length_);

      float l_calibers = L_inches / d_inches;

      float numerator = 30.0f * m_grains;
      float denominator = stability_factor * L_inches * (1.0f + l_calibers * l_calibers);

      if(denominator <= 0.0f)
        return 0.0f;

      return std::sqrt(numerator / denominator);
    }

    private:
    float weight_;   // kg
    float diameter_; // m
    float length_;   // m
    float bc_;
    DragFunction drag_function_;

    // Flight state (only valid if has_flight_state_ is true)
    btk::math::Vector3D position_; // m
    btk::math::Vector3D velocity_; // m/s
    float spin_rate_;              // rad/s
    bool has_flight_state_;
  };

} // namespace btk::ballistics
