// Normal variation with outliers clipped at three standard deviations,
// matching the distribution used by the C++ match simulator.
export function clippedNormalVariation(sd)
{
  if (sd <= 0) return 0;

  // 1 - random is in (0, 1], avoiding log(0).
  const u = 1 - Math.random();
  const v = Math.random();
  const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  return Math.max(-3, Math.min(3, z)) * sd;
}
