# 19 System Of Things Sot

**Project:** BALLISTICSTOOLKIT
**Upstream:** https://github.com/chasep255/BallisticsToolkit

Content specific to BALLISTICSTOOLKIT in category ARTILLERY_MANUFACTURING.
