# 21 Related Scientific Research

**Project:** BALLISTICSTOOLKIT
**Upstream:** https://github.com/chasep255/BallisticsToolkit

Content specific to BALLISTICSTOOLKIT in category ARTILLERY_MANUFACTURING.
