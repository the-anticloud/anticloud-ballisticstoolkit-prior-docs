# Anticommons License 0.1.0

**Project:** BALLISTICSTOOLKIT
**Upstream:** https://github.com/chasep255/BallisticsToolkit (MIT)

The upstream code retains its original MIT license.

All Anticloud-authored additions — including PAX L5 Narrow L2 General 27B integration,
AIOSS ledger hooks, encryption layer, offline deployment scripts, and branding —
are licensed under the Anticommons License 0.1.0.

Anticommons 0.1.0 is a permissive license that allows use, modification, and distribution
provided the Anticloud FZ LLE copyright notice is retained.

Full license text: E:\fenta\Downloads\The Anticloud\Anticommons_0.1.0\LICENSE
